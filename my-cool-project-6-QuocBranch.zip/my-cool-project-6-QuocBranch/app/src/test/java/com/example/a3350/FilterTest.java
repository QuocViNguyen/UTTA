package com.example.a3350;

import org.junit.Before;
import org.junit.Test;
import com.example.a3350.logic.Filter;
import com.example.a3350.objects.Course;
import com.example.a3350.objects.Posting;
import com.example.a3350.objects.User;
import com.example.a3350.objects.Institution;

import java.util.List;
import java.util.Arrays;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

//(list of postings, string name, int id)

public class FilterTest {
    private List<Posting> testList;

    private Institution institution1 = new Institution("UofU", "@UU.ca");

    private Course course1 = new Course("COMP", 101, "5th Year Binary", institution1);
    private Course course2 = new Course("COMP", 1020, "Intro Comp Sci", institution1);
    private Course course3 = new Course("PHIL", 1000, "What is Philosophy?", institution1);
    private Course course4 = new Course("PHIL", 4000, "Why is Philosophy?", institution1);
    private List<Course> courseList;

    private User owner1 = new User("John Doe", institution1, "John@UU.ca", "Password");
    private User owner2 = new User("Not Doe", institution1, "Not@UU.ca", "Password");

    private Posting posting1 = new Posting(owner1, course1, "book1", 100.10, "Good book", true, 5);
    private Posting posting2 = new Posting(owner1, course2, "book2", 230.10, "Bad book", true, 8);
    private Posting posting3 = new Posting(owner1, course3, "book2", 50.40, "Bad book", true, 6);
    private Posting posting4 = new Posting(owner1, course4, "book3", 100.20, "Lame book", true, 7);
    private Posting posting5 = new Posting(owner1, course2, "book4", 0.10, "Rad book", true, 5);
    private Posting posting6 = new Posting(owner2, course2, "book5", 0.10, "Fad book", true, 5);

    private List<Posting> course2Filtered = Arrays.asList(posting2, posting5);
    private List<Posting> COMPFiltered = Arrays.asList(posting1, posting2, posting5);
    private List<Posting> priceSorted = Arrays.asList(posting5, posting3, posting1, posting4, posting2);
    private List<Posting> UserSorted = Arrays.asList(posting1, posting2, posting3, posting4, posting3);

    @Before
    public void setup()
    {
        testList = Arrays.asList(posting1, posting2, posting3, posting4, posting5, posting6);
        courseList = Arrays.asList(course1,course2,course3,course4);
    }

    @Test
    public void CourseFilterTest() {
        assertThat(Filter.byCourses(testList, course2.getFaculty(), course2.getCourseID()), is(course2Filtered));
    }

    @Test
    public void PriceSortTest(){
        Filter.sortByPrices(testList);
        assertThat(testList, is(priceSorted));
    }

    @Test
    public void FacultyFilterTest(){
        assertThat(Filter.byFaculty(testList, course1.getFaculty()), is(COMPFiltered));
    }

    @Test
    public void UserNameTesting(){
        assertThat(Filter.byUserEmail(testList,owner1.getEmail()), is(UserSorted));
    }

    @Test
    public void getUserByEmailTest(){
        assertThat(Filter.getUserByEmail(owner1.getEmail()),is(owner1));

    }

    @Test
    public void getCoursebyFacultyTest(){
        List<Course> courses = Filter.getCoursesByFaculty(courseList,"ENG");
        assertThat(courses.get(0).getCourseName(), is ("Something"));
        assertThat(courses.get(0).getCourseID(), is (3130));
    }

    @Test
    public void getCourseByNameTest(){

    }

}
