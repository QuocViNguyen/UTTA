package com.example.a3350;

import org.junit.Test;
import com.example.a3350.logic.LoginChecker;

import static org.junit.Assert.*;


public class LoginTest {

    @Test
    public void validUserCheckTest() {
        assertTrue(LoginChecker.check("lucilleb@umanitoba.ca", "123456"));
    }

    @Test
    public void invalidUserNameTest() {
        assertFalse(LoginChecker.check("lucille@umanitoba.ca", "123456"));
    }

    @Test
    public void invalidPassTest() {
        assertFalse(LoginChecker.check("lucilleb@umanitoba.ca", "12345"));
    }

    @Test
   public void noAtUserCheckTest(){
        assertFalse( LoginChecker.check("lucillebumanitoba.ca", "123456"));
    }

    @Test
    public void badDomainUserCheckTest(){
        assertFalse( LoginChecker.check("lucilleb@umanitoba.c", "123456"));
    }

    @Test
    public void multipleDomainUserCheckTest(){
        assertFalse( LoginChecker.check("lucilleb@umanitoba.ca@redriver.ca", "123456"));
    }

    @Test
    public void shortUserCheckTest(){
        assertFalse( LoginChecker.check("lub@umanitoba.ca", "123456"));
    }

    @Test
    public void longUserCheckTest(){
        assertFalse( LoginChecker.check("lluucciilllleebb@umanitoba.ca", "123456"));
    }

    @Test
    public void emptyUserCheckTest(){
        assertFalse( LoginChecker.check("", "123456"));
    }

    @Test
    public void validPassCheckTest(){
        assertTrue( LoginChecker.check("lucilleb@umanitoba.ca", "123456789"));
    }

    @Test
    public void shortPassCheckTest(){
        assertFalse( LoginChecker.check("lucilleb@umanitoba.ca", "123"));
    }

    @Test
    public void longPassCheckTest() {
        assertFalse(LoginChecker.check("lucilleb@umanitoba.ca", "1234567891234567"));
    }

    @Test
    public void equalPassCheckTest() {
        assertFalse(LoginChecker.check("user=password", "user=password"));
    }
}
