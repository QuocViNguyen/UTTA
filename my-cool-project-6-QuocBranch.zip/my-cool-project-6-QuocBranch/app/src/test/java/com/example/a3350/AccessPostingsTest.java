package com.example.a3350;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import com.example.a3350.logic.AccessPostings;
import com.example.a3350.objects.Course;
import com.example.a3350.objects.Institution;
import com.example.a3350.objects.Posting;
import com.example.a3350.objects.User;

import static org.junit.Assert.*;

public class AccessPostingsTest {

    private AccessPostings postTester = new AccessPostings();
    private List<Posting>  testList = postTester.getPostings();

    private Institution institution1 = new Institution("UofU", "@UU.ca");

    private Course course1 = new Course("PHIL", 1000, "What is Philosophy?", institution1);

    private User owner1 = new User("John Doe", institution1, "John@UU.ca", "Password");


    @Before
    public void setup()
    {
        testList = postTester.getPostings();
    }

    @Test
    public void accessPostTest(){
        assertEquals(testList.get(0).getOwner().getName(), "Gene Parmesan");
        assertEquals(testList.get(1).getTitle(), "Analyse Algorithms");
        assertEquals(testList.get(2).getDetail(), "Introduction to Computer Graphics");
    }

    @Test
    public void addPostTest(){
        postTester.addPosting(owner1, course1, "book1", 100.10, "Good book", true, 5);
        assertEquals(testList.get(3).getHowOld(), 5);
    }
}