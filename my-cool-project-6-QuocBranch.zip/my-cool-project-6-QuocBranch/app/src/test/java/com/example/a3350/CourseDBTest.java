package com.example.a3350;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.a3350.data.database.CourseDatabase;

import static org.junit.Assert.assertEquals;

public class CourseDBTest {
    private CourseDatabase courseDB;
    private String dbPath= "data/user/0/com.example.a3350/app_db/SC";
    DBTesting test = new DBTesting();

    @Before
    public void setup(){
        this.courseDB = new CourseDatabase(dbPath);
        test.setup();
    }

    @After
    public void collapseTables(){
        test.collapseTables();
    }

//    @Test
//    public void searchCourseTest(){
//        assertEquals("Literary Comprehension", courseDB.searchCourse("LICO101").getCourseName());
//    }


    @Test
    public void getCoursesTest(){
        assertEquals(101, courseDB.getCourses().get(0).getCourseID());
    }

    @Test
    public void getFacultiesTest(){
        assertEquals("COMP", courseDB.getFaculties().get(0));
    }
//
//    @Test
//    public void removeCourseTest(){
//        courseDB.removeCourse(courseDB.getCourses().get(0));
//        assertEquals(1234, courseDB.getCourses().get(0).getCourseID());
//    }

//    @Test
//    public void updateCourseInstitutionTest(){
//        courseDB.updateCourseInstitution(courseDB.getCourses().get(0), courseDB.getCourses().get(1).getInstitution());
//        assertEquals("Red River College", courseDB.getCourses().get(1).getInstitution().getName());
//    }

//    @Test
//    public void updateCourseInformationTest(){
//        Course course = courseDB.getCourses().get(0);
//        course.setInstitution(courseDB.getCourses().get(1).getInstitution());
//        courseDB.updateCourse(course);
//        assertEquals("Red River College", courseDB.getCourses().get(1).getInstitution().getName());
//    }

}
