package com.example.a3350;

import com.example.a3350.data.database.InstitutionDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertEquals;

public class InstitutionDBTest {
    private InstitutionDatabase instDB;
    private String dbPath= "app/src/main/java/Test_Server/Server";
    DBTesting test = new DBTesting();

    @Before
    public void setup(){
        this.instDB = new InstitutionDatabase(dbPath);
        test.setup();
    }

    @After
    public void collapseTables(){
        test.collapseTables();
    }

//    @Test
//    public void searchInstitutionTest(){
//        assertEquals("umanitoba.ca", instDB.searchInstitution("University of Manitoba").getDomain());
//    }
}
