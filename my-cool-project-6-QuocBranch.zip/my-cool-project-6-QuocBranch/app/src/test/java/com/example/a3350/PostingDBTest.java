package com.example.a3350;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.a3350.data.database.PostingDatabase;
import com.example.a3350.objects.Posting;
import com.example.a3350.objects.User;
import com.example.a3350.objects.Course;
import com.example.a3350.objects.Institution;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class PostingDBTest {
    private PostingDatabase postDB;
    private String dbPath= "data/user/0/com.example.a3350/app_db/SC";
    DBTesting test = new DBTesting();

    @Before
    public void setup(){
        this.postDB = new PostingDatabase(dbPath);
        test.setup();
    }

    @After
    public void collapseTables(){
        test.collapseTables();
    }

    @Test
    public void getPostingsTest(){
        assertEquals(1, postDB.getPostings().get(1).getId());
    }

    @Test
    public void addPostingTest(){
        final User owner = postDB.getPostings().get(0).getOwner();
        final Course course = postDB.getPostings().get(0).getCourse();
        final Posting newPost = new Posting(owner, course, "", 42.31,
                "Really gets you in the right state to learn.", false, 1);
        assertNotNull(owner.getEmail());
        assertEquals("101", course.getCourseID());
        assertNotNull(newPost);
        assertEquals(2, newPost.getId());
        postDB.addPosting(owner,course,"Algorithms Step-by-Step", 42.31,"Really gets you in the right state to learn.", false, 1);

        assertEquals(2, postDB.getPostings().get(2).getId());
    }

    @Test
    public void removePostingTest(){
        postDB.removePosting(postDB.getPostings().get(0));
        assertEquals(1, postDB.getPostings().get(0).getId());
    }

    @Test
    public void updatePostingTest(){
        Posting post = postDB.getPostings().get(0);
        post.setHighlighted(true);
        post.setHowOld(99);
        postDB.updatePosting(post.getId(),post.getTitle(), post.getDetail(), post.getCourse(), post.isHighlighted(),post.getPrice(),post.getHowOld());
        assertEquals(true, postDB.getPostings().get(0).isHighlighted());
        assertEquals(99, postDB.getPostings().get(0).getHowOld());
    }

//    @Test
//    public void updateCourseTest(){
//        Posting post = postDB.getPostings().get(0);
//        postDB.updateCourse(post, new Course("COMP", "1234", "Algorithms", new Institution("Red River College", "rrc.ca")));
//        assertEquals(1234, postDB.getPostings().get(0).getCourse().getCourseID());
//    }
//
//    @Test
//    public void setPricePostingTest(){
//        Posting post = postDB.getPostings().get(0);
//        postDB.setPricePosting(post, 0.06);
//        assertEquals(0.06, postDB.getPostings().get(0).getPrice(), 0.01);
//    }
//
//    @Test
//    public void setDetailPosting(){
//        Posting post = postDB.getPostings().get(0);
//        postDB.setDetailPosting(post, "PleaseBuyThis");
//        assertEquals("PleaseBuyThis", postDB.getPostings().get(0).getDetail());
//    }
//
//    @Test
//    public void setTitlePosting(){
//        Posting post = postDB.getPostings().get(0);
//        postDB.setTitlePosting(post, "NewTitle");
//        assertEquals("NewTitle", postDB.getPostings().get(0).getTitle());
//    }
//
//    @Test
//    public void setHowOldPosting(){
//        Posting post = postDB.getPostings().get(0);
//        postDB.setHowOldPosting(post, 0);
//        assertEquals(0, postDB.getPostings().get(0).getHowOld());
//    }

}
