package com.example.a3350;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
        AccessPostingsTest.class,
        FilterTest.class,
        LoginTest.class,
        IntegrationTests.class})

public class AllTests {

}
