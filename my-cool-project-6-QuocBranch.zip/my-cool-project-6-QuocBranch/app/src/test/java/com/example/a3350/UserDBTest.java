package com.example.a3350;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.example.a3350.data.database.UserDatabase;
import com.example.a3350.objects.Institution;
import com.example.a3350.objects.User;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class UserDBTest {
    private UserDatabase userDB;
    private String dbPath= "data/user/0/com.example.a3350/app_db/SC";
    DBTesting test = new DBTesting();

    @Before
    public void setup(){
        this.userDB = new UserDatabase(dbPath);
        test.setup();
    }

    @After
    public void collapseTables(){
       test.collapseTables();
    }

//    @Test
//    public void searchUserTest(){
//        assertEquals("Quoc", userDB.searchUser("nguyenvq@myumanitoba.ca").getName());
//    }

//    @Test
//    public void addUserTest(){
//        final Institution uOfm = new Institution("University of Manitoba", "umanitoba.ca");
//
//        final User user = new User("Sam", uOfm, "samp@umanitoba.ca", "123456");
//        userDB.addUser(user);
//        assertEquals("Sam", userDB.searchUser("samp@umanitoba.ca").getName());
//    }

//    @Test
//    public void removeUserTest(){
//        assertEquals("Quoc", userDB.searchUser("nguyenvq@myumanitoba.ca").getName());
//        userDB.removeUser(userDB.searchUser("nguyenvq@myumanitoba.ca"));
//        assertNull(userDB.searchUser("nguyenvq@myumanitoba.ca"));
//    }
//
//    @Test
//    public void changePasswordTest(){
//        userDB.changePassUser(userDB.searchUser("nguyenvq@myumanitoba.ca"), "newPass");
//        assertEquals(userDB.searchUser("nguyenvq@myumanitoba.ca").getPassword(), "newPass");
//    }

}
