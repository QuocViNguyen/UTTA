package com.example.a3350.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.a3350.R;
import com.example.a3350.logic.AccessPostings;
import com.example.a3350.logic.Constants;
import com.example.a3350.logic.Filter;
import com.example.a3350.objects.Posting;

import java.util.List;

import static com.example.a3350.ui.LoginActivity.currentUser;

public class PostingActivity extends Activity
{
    AccessPostings accessPostings;
    ListView postingListView;
    List<Posting> postings;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posting);
        accessPostings = new AccessPostings();
        postings = accessPostings.getPostings();
        postings = Filter.getPostingsByUserInstitution(currentUser.getInstitution());

        final Intent intent = getIntent();
        final String courseName = intent.getStringExtra("COURSE FACULTY");
        final int courseID = intent.getIntExtra("COURSE ID", 0);

        final String faculty = intent.getStringExtra("FACULTY");
        final String filterBy = intent.getStringExtra(Constants.filterBy);

        TextView filteredByTextView = findViewById(R.id.filteredByTextView);

        //postings will be shown according to which button called this activity
        if(filterBy != null && filterBy.equals(Constants.course))
        {
            postings = Filter.byCourses(postings,courseName, courseID);
            String course = faculty + courseID;
            filteredByTextView.setText(course);
        }
        else if (filterBy != null && filterBy.equals(Constants.faculty))
        {
            postings = Filter.byFaculty(postings, faculty);
            filteredByTextView.setText(faculty);
        }

        postingListView = findViewById(R.id.postingListView);

        final ArrayAdapter<Posting> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, postings);
        postingListView.setAdapter(adapter);

        postingListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent;
                Bundle extras = new Bundle();
                extras.putInt(Constants.calling_activity, Constants.VIEW_POST);

                intent = new Intent(getApplicationContext(), PostActivity.class);

                extras.putString(Constants.title, postings.get(i).getTitle());
                extras.putString(Constants.detail, postings.get(i).getDetail());
                extras.putBoolean(Constants.highlighted, postings.get(i).isHighlighted());
                extras.putDouble(Constants.price, postings.get(i).getPrice());
                extras.putString(Constants.course, postings.get(i).getCourse().toString());
                extras.putString(Constants.faculty, postings.get(i).getCourse().getFaculty());
                extras.putInt(Constants.age, postings.get(i).getHowOld());
                extras.putString(Constants.username,postings.get(i).getOwner().getName());
                extras.putString(Constants.institution,postings.get(i).getOwner().getInstitution().getName());
                extras.putString(Constants.email, postings.get(i).getOwner().getEmail());
                intent.putExtras(extras);
                startActivity(intent);
            }
        });
    }
}