package com.example.a3350.data;

import com.example.a3350.objects.Institution;
import java.util.List;

public interface InstitutionDataInterface
{
    List<Institution> getInstitutions();
}
