package com.example.a3350.logic;

import com.example.a3350.data.AllData;
import com.example.a3350.objects.Institution;

import java.util.List;

public class AccessInstitutions
{
    private List<Institution> institutions;

    public AccessInstitutions()
    {
        institutions = AllData.getInstitutionData().getInstitutions();
    }

    public List<Institution> getInstitutions()
    {
        return institutions;
    }
}
