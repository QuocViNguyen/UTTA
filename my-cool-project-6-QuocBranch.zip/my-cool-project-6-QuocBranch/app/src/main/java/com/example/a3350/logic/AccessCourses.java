package com.example.a3350.logic;

import com.example.a3350.data.AllData;
import com.example.a3350.data.CourseDataInterface;
import com.example.a3350.objects.Course;

import java.util.List;

public class AccessCourses
{
    private List<Course> courses;
    private List<String> faculties;

    public AccessCourses()
    {
        CourseDataInterface courseDataInterface = AllData.getCourseData();
        courses = courseDataInterface.getCourses();
        faculties = courseDataInterface.getFaculties();
    }

    public List<Course> getCourses()
    {
        return courses;
    }

    public List<String> getFaculties()
    {
        return faculties;
    }
}
