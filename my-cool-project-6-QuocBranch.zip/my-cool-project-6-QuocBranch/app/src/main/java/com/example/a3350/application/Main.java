package com.example.a3350.application;

public class Main
{
    private static String dbName="data/user/0/com.example.a3350/app_db/SC";

    public static void main(String[] args) {}

    public static void run()
    {
        try
        {
            Class.forName("org.hsqldb.jdbcDriver");
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void setDBPathName(final String name){
        try {
            Class.forName("org.hsqldb.jdbcDriver").newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        dbName = name;
    }


    public static String getDBPathName()
    {
        return dbName;
    }

}
