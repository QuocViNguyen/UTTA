package com.example.a3350.logic;


public interface Constants
{
    boolean usingDatabase = true;
    int ADD_POST = 1;
    int VIEW_POST = 2;
    int EDIT_POST = 3;
    int USER_PROFILE = 4;
    int MY_PROFILE = 5;
    String calling_activity = "calling_activity";
    String title = "title";
    String detail = "details";
    String price = "price";
    String age = "age";
    String highlighted = "highlighted";
    String faculty = "faculty";
    String course = "course";
    String username = "username";
    String institution = "institution";
    String id = "id";
    String allGood = "Account created successfully.";
    String filterBy = "Filter By";
    String userPosts = "User's posts";
    String whatToShowNext = "showing (courses, faculties, or postings)";
    String postings = "postings";
    String editAccount = "edit account";
    String email = "emails";
    String from = "viewing posts from user profile or from list of posts";
}
