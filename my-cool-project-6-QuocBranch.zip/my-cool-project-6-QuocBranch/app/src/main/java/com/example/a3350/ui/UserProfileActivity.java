package com.example.a3350.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;


import com.example.a3350.R;
import com.example.a3350.logic.AccessPostings;
import com.example.a3350.logic.AccessUsers;
import com.example.a3350.logic.Constants;
import com.example.a3350.logic.Filter;
import com.example.a3350.objects.Posting;
import com.example.a3350.objects.User;

import java.util.ArrayList;
import java.util.List;

import static com.example.a3350.ui.LoginActivity.currentUser;

public class UserProfileActivity extends Activity
{
    RatingBar usersRatingBar, newUsersRating;
    TextView ratedByTextView, nameUserProfile, emailUserProfile;
    Button submitRatingButton;
    User poster;
    String posterName, posterEmail;
    ListView usersPostListView;
    AccessPostings accessPostings;
    AccessUsers accessUsers;
    List<Posting> postings;
    List<User> users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);
        accessPostings = new AccessPostings();
        accessUsers = new AccessUsers();
        //a shallow copy because we don't want to change the original list
        postings = new ArrayList<>(accessPostings.getPostings());
        users = accessUsers.getUsers();
        Intent intent = getIntent();

        nameUserProfile = findViewById(R.id.nameUserProfile);
        emailUserProfile = findViewById(R.id.emailUserProfile);
        ratedByTextView = findViewById(R.id.ratedByTextView);
        submitRatingButton = findViewById(R.id.submitRatingButton);
        usersPostListView = findViewById(R.id.usersPostListView);
        usersRatingBar = findViewById(R.id.usersRatingBar);
        newUsersRating = findViewById(R.id.usersNewRating);

        final int callingActivity = intent.getIntExtra(Constants.calling_activity,0);
        if(callingActivity == Constants.USER_PROFILE)
        {
            posterName = intent.getStringExtra(Constants.username);
            posterEmail = intent.getStringExtra(Constants.email);
            poster = Filter.getUserByEmail(posterEmail);
        }
        //poster and current user are the same if MY PROFILE button is clicked
        else if(callingActivity == Constants.MY_PROFILE)
        {
            posterName = currentUser.getName();
            posterEmail = currentUser.getEmail();
            poster = currentUser;
            submitRatingButton.setEnabled(false);
        }

        postings = Filter.byUserEmail(postings, posterEmail);
        final ArrayAdapter<Posting> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, postings);
        usersPostListView.setAdapter(adapter);

        usersPostListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                Intent intent1 = new Intent(getApplicationContext(), PostActivity.class);
                Bundle extras = new Bundle();
                if(callingActivity == Constants.USER_PROFILE)
                {
                    extras.putInt(Constants.calling_activity, Constants.VIEW_POST);
                    extras.putBoolean(Constants.from, true);
                }
                else
                    extras.putInt(Constants.calling_activity, Constants.EDIT_POST);

                extras.putInt(Constants.id, postings.get(i).getId());
                extras.putString(Constants.title, postings.get(i).getTitle());
                extras.putString(Constants.detail, postings.get(i).getDetail());
                extras.putBoolean(Constants.highlighted, postings.get(i).isHighlighted());
                extras.putDouble(Constants.price, postings.get(i).getPrice());
                extras.putString(Constants.course, postings.get(i).getCourse().toString());
                extras.putString(Constants.faculty, postings.get(i).getCourse().getFaculty());
                extras.putInt(Constants.age, postings.get(i).getHowOld());
                extras.putString(Constants.username,postings.get(i).getOwner().getName());
                extras.putString(Constants.institution,postings.get(i).getOwner().getInstitution().getName());
                extras.putString(Constants.email, postings.get(i).getOwner().getEmail());
                intent1.putExtras(extras);
                startActivity(intent1);
            }
        });


        setValues();
        submitRatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                float newRating = newUsersRating.getRating();
                accessUsers.addRating(poster,newRating,currentUser.getEmail());
                setValues();
            }
        });
    }
    private void setValues()
    {
        nameUserProfile.setText(posterName);
        emailUserProfile.setText(posterEmail);

        usersRatingBar.setRating(accessUsers.getRating(poster));
        float ratingForPoster = accessUsers.getRatingFromUser(poster,currentUser.getEmail());
        newUsersRating.setRating(ratingForPoster);
        ratedByTextView.setText(String.valueOf(accessUsers.getRatedBy(poster)));
    }
}
