package com.example.a3350.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.a3350.R;
import com.example.a3350.logic.Constants;

//should we do this?
import static com.example.a3350.ui.LoginActivity.currentUser;

public class HomepageActivity extends Activity implements View.OnClickListener
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        TextView homepageUsernameTV = findViewById(R.id.homepageUsernameTV);
        homepageUsernameTV.setText(currentUser.getName());

        Button postingsButton = findViewById(R.id.postingsButton);
        Button addPostButton = findViewById(R.id.addPostButton);
        Button editAccountButton = findViewById(R.id.editAccountButton);
        Button logoutButton = findViewById(R.id.logoutButton);
        Button myPostButton = findViewById(R.id.myProfileButton);

        postingsButton.setOnClickListener(this);
        addPostButton.setOnClickListener(this);
        editAccountButton.setOnClickListener(this);
        logoutButton.setOnClickListener(this);
        myPostButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.postingsButton:
                Intent postingTabIntent = new Intent(getApplicationContext(), PostingTabsActivity.class);
                startActivity(postingTabIntent);
                break;
            case R.id.myProfileButton:
                Intent myProfileIntent = new Intent(getApplicationContext(), UserProfileActivity.class);
                myProfileIntent.putExtra(Constants.calling_activity, Constants.MY_PROFILE);
                startActivity(myProfileIntent);
                break;
            case R.id.addPostButton:
                Intent addPostIntent = new Intent(getApplicationContext(), PostActivity.class);
                addPostIntent.putExtra(Constants.calling_activity, Constants.ADD_POST);
                startActivity(addPostIntent);
                break;
            case R.id.editAccountButton:
                Intent editAccountIntent = new Intent(getApplicationContext(), AccountActivity.class);
                editAccountIntent.putExtra(Constants.editAccount, true);
                startActivity(editAccountIntent);
                break;
            case R.id.logoutButton:
                finish();
                break;
        }
    }
}
