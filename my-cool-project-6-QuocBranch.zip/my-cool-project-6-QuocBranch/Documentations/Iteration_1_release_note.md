#Iteration 1 release

-Added non-persistent account creation 
-- Specific help messages displayed if any entry is invalid 
-Added login/logout
--(Sample emails: mbluth@umanitoba.ca, lucilleb@umanitoba.ca, lindsab@umanitoba.ca Passwords all the same: 123456)
-Enabled viewing of pre-made postings 
-Postings categorized by course 
